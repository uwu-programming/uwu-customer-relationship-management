<script setup>
    import activity_view_div from "../components/activity_page/activity_view_div.vue";
</script>

<template>
    <activity_view_div></activity_view_div>
</template>