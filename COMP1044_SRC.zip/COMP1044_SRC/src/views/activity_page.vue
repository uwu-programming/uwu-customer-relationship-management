<script setup>
    import activity_display_div from "../components/activity_page/activity_display_div.vue";
</script>

<template>
    <activity_display_div></activity_display_div>
</template>