<script setup>
    import company_edit from "../components/company_page/company_edit.vue";
</script>

<template>
    <company_edit></company_edit>
</template>