<script setup>
    import user_creation_div from "../components/user_page/user_creation_div.vue";
</script>

<template>
    <user_creation_div></user_creation_div>
</template>