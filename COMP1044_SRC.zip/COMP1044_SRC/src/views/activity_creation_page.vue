<script setup>
    import activity_creation_div from "../components/activity_page/activity_creation_div.vue";
</script>

<template>
    <activity_creation_div></activity_creation_div>
</template>