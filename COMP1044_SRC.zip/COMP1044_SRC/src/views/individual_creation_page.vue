<script setup>
    import individual_creation_div from '../components/individual_creation/individual_creation_div.vue';
</script>

<template>
    <individual_creation_div></individual_creation_div>
</template>