<script setup>
    import company_creation_div from "../components/company_page/company_creation_div.vue";
</script>

<template>
    <company_creation_div></company_creation_div>
</template>