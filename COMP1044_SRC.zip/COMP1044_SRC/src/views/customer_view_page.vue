<script setup>
    import customer_view_div from "../components/customer_page/customer_view_div.vue";
</script>

<template>
    <customer_view_div></customer_view_div>
</template>