<script setup>
    import my_profile_div from "../components/user_page/my_profile_div.vue";
</script>

<template>
    <my_profile_div></my_profile_div>
</template>