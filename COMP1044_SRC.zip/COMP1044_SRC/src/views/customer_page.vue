<script setup>
    import customer_display_div from "../components/customer_page/customer_display_div.vue";
</script>

<template>
    <customer_display_div></customer_display_div>
</template>