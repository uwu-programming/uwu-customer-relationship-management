<script setup>
    import contact_edit from "../components/customer_page/customer_edit.vue";
</script>

<template>
    <contact_edit></contact_edit>
</template>