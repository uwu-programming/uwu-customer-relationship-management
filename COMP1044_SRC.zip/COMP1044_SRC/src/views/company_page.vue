<script setup>
    import company_display_div from "../components/company_page/company_display_div.vue";
</script>

<template>
    <company_display_div></company_display_div>
</template>