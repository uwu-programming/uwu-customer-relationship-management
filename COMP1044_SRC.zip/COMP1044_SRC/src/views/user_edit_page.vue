<script setup>
    import user_edit from "../components/user_page/user_edit.vue";
</script>

<template>
    <user_edit></user_edit>
</template>