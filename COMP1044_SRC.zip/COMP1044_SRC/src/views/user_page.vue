<script setup>
    import user_display_div from '../components/user_page/user_display_div.vue';
</script>

<template>
    <user_display_div></user_display_div>
</template>