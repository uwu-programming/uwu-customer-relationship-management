<script setup>
    import login_div from '../components/login_page/login_div.vue';
</script>

<template>
    <div class="flex w-screen h-screen bg-gradient-to-r bg-linear-to-bl from-violet-500 to-fuchsia-500">
        <div class="flex flex-col w-550 justify-center items-center">
            <h1 class="text-center mb-10 text-2xl font-bold decoration-2 underline">UwU ABB<br>Customer Relationship Management System</h1>
            <login_div></login_div>
        </div>
    </div>
</template>