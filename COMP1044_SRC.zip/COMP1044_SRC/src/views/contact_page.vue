<script setup>
    import contact_display_div from "../components/contact_page/contact_display_div.vue";
</script>

<template>
    <contact_display_div></contact_display_div>
</template>