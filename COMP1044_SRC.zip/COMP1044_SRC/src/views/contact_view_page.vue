<script setup>
    import contact_view_div from "../components/contact_page/contact_view_div.vue";
</script>

<template>
    <contact_view_div></contact_view_div>
</template>