<script setup>
    import activity_edit from "../components/activity_page/activity_edit.vue";
</script>

<template>
    <activity_edit></activity_edit>
</template>