<script setup>
    import lead_display_div from '../components/lead_page/lead_display_div.vue';
</script>

<template>
    <lead_display_div></lead_display_div>
</template>