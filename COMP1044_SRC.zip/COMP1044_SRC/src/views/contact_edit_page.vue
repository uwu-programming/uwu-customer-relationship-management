<script setup>
    import contact_edit from "../components/contact_page/contact_edit.vue";
</script>

<template>
    <contact_edit></contact_edit>
</template>