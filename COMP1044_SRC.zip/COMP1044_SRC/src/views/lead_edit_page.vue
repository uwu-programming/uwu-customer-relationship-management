<script setup>
    import lead_edit from '../components/lead_page/lead_edit.vue';
</script>

<template>
    <lead_edit></lead_edit>
</template>